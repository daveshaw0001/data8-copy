test = {   'name': 'q1_1_2',
    'points': [0],
    'suites': [   {   'cases': [{'code': '>>> (type(most_stem) == str) | (type(most_stem) == np.str_)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
