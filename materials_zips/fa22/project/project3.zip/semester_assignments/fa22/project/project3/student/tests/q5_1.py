test = {   'name': 'q5_1',
    'points': [2],
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> import hashlib\n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness"""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> \n'
                                               '>>> get_hash(add_partner) # Your secret word is incorrect. \n'
                                               "'f827cf462f62848df37c5e1e94a4da74'",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
